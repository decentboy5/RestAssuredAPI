package sample;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

public class GetPayCodeValidations {
  @Test
  public void f() {
  }
  @BeforeClass
  public void beforeClass() {
  }

}
