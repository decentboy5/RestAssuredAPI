package ezlm.backup;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.json.simple.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import ezlm.APIAutomation.Utilities.APIResponseMessages;
import ezlm.APIAutomation.Utilities.APICall;
import ezlm.APIAutomation.Utilities.Excel;
import ezlm.APIAutomation.Utilities.Headers;
import ezlm.APIAutomation.Utilities.URIConfigurations;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllPayCodes_old {

	public static HashMap<String, String> headers = null;
	public static String FilePath="C:\\Naidu\\ATS.xlsx";
	

@BeforeClass
public void beforePaycodeClass()
{
	
}


@Test
public void GetPayCodes_With_Valid_Values() throws IOException
{
	////Get headers from Excel 
	//headers=Excel.GetExcelData(FilePath, "Sheet6", 2);
	
	headers=Headers.getHeaders("PayCode/GetHeaders.properties");
	
	//  Get Call with URI and Headers 
	Response response=APICall.GetAPIcall(URIConfigurations.GetAllPayCodesURI, null, headers);
	
	// validations  
	APICall.verify_response(response, "data.options.value","PERSONAL");
	APICall.verify_Response_StatusCode(response, APIResponseMessages.StatusCode_200);
	APICall.verify_Response_StatusLine(response, APIResponseMessages.StatusLine_HTTP_200);
	APICall.verify_Response_Header(response, APIResponseMessages.Header_content_type);
	APICall.verify_Response_Header(response, APIResponseMessages.Header_Connection);
}


@Test
public void GetPayCodes_Without_Culture() throws IOException
{
	
	// Get headers from Excel 
	//headers=Excel.GetExcelData(FilePath, "Sheet6", 3);
	
	headers=Headers.getHeaders("PayCode/GetHeaders.properties");
	headers.replace("culture", "");
	//Get Call with URI and Headers 
	Response response=APICall.GetAPIcall(URIConfigurations.GetAllPayCodesURI, null, headers);
	
	 //validations  
	APICall.verify_response(response, "data.statusDescription","Need a valid value for culture");
	APICall.verify_Response_StatusCode(response, APIResponseMessages.StatusCode_401);
	APICall.verify_Response_StatusLine(response, APIResponseMessages.StatusLine_HTTP_401);
	APICall.verify_response(response, "data.status", APIResponseMessages.failure_status);
	APICall.verify_response(response, "data.statusCode",APIResponseMessages.StatusCode_404);
	APICall.verify_Response_Header(response, APIResponseMessages.Header_content_type);
	APICall.verify_Response_Header(response, APIResponseMessages.Header_Connection);
}


@SuppressWarnings("unchecked")
@Test
public void abc() throws IOException
{
	
	String uri = "http://mascsr.dit.oneadp.com/mascsr/wfntlm/config/v1";
	
	headers=Excel.GetExcelData(FilePath, "header", 2);
	RestAssured.baseURI = uri;
	RequestSpecification request = RestAssured.given();

	request.header("Content-Type", "application/json");
	Set<Entry<String, String>> headersset = headers.entrySet();
	Iterator<Entry<String, String>> _headers = headersset.iterator();
	while (_headers.hasNext()) {
		Entry<String, String> data = _headers.next();
		request.header(data.getKey(), data.getValue());
	}

	JSONObject requestParams = new JSONObject();
	requestParams.put("payCodeId", "Z2DA"); // Cast
	requestParams.put("payType", "normal");
	requestParams.put("workedType", "worked");
	requestParams.put("alreadyPaidPayCode", null);	
	requestParams.put("transferToPayroll",  "true");
	requestParams.put("jobHierarchy", "none");
	requestParams.put("rateCalcType", "payCodeRate");
	requestParams.put("payrollXferCodes", "73562.12");
	requestParams.put("canEnterOnTimeCard", "true");
	requestParams.put("distributeTime", "false");
	requestParams.put("defaultAmount", "100");
	requestParams.put("guaranteedHrs", "100");
	requestParams.put("entryType", "hours");
	requestParams.put("sendToClocks", "false");
	requestParams.put("guaranteedShiftDiff","false");
	requestParams.put("useWageRateProgram", "false");
	requestParams.put("includeInZooms", "true");
	requestParams.put("excludeHrsFromViews","false");
	requestParams.put("useAvgProHours", "false");
	requestParams.put("useAvgProWage", "false");
	requestParams.put("useScheduledHolidayHours", "false");
	requestParams.put("countForProbation", "true");
	requestParams.put("countForWorkTime", "true");
	requestParams.put("countForAvgDay", "false");
	requestParams.put("suppresSOTs", "false");	
	requestParams.put("activateAlternateThreshold", "false");	
	requestParams.put("countForShiftDiff", "true");	
	requestParams.put("excludeFromTimeGen", "false");	
	requestParams.put("countAsPaid", "true");	
	requestParams.put("timeCardColumn", 1);
	
/*	requestParams.put("", "");	
	requestParams.put("", "");	
	requestParams.put("", "");	*/
	List<Object> s=new LinkedList<Object>();
	JSONObject s1 = new JSONObject();
	s1.put("payGroupId", "SALARY");
	s1.put("includeInZooms", "true");
	s.add(s1);
	requestParams.put("payGroupList",s);
	JSONObject s2 = new JSONObject();
	s2.put("effectiveDate", "2018-06-20");
	s2.put("rateAmount", 7);
	s=new LinkedList<Object>();
	s.add(s2);
	requestParams.put("payCodeRates",s);
	requestParams.put("payShiftDiff", "true");
	JSONObject s3 = new JSONObject();
	s3.put("culture", "en-US");
	s3.put("description", "Regular");
	s=new LinkedList<Object>();
	s.add(s3);
	requestParams.put("descriptions",s);
	System.out.println(requestParams.toJSONString());
	request.body(requestParams.toJSONString());
	
	Response response = request.post("/paycode.add");
	System.out.println("Response body: " + response.body().asString());
}

}
