package ezlm.testsuite.paycode_testcases;

import java.io.IOException;
import org.testng.annotations.Test;

import ezlm.APIAutomation.Utilities.APIResponseMessages;
import ezlm.APIAutomation.Utilities.APIBaseClass;
import ezlm.APIAutomation.Utilities.APICall;
import ezlm.APIAutomation.Utilities.APIResponse;
import ezlm.APIAutomation.Utilities.Headers;
import ezlm.APIAutomation.Utilities.URIConfigurations;
import io.restassured.response.Response;

public class GetPayCodeByID extends APIBaseClass {

	@Test(priority = 1)
	public void GetPayCodes_With_Valid_Values() throws IOException {

		// Get Headers from Property File
		headers = Headers.getHeaders("PayCode/GetHeaders.properties");

		// Get Call with URI and Headers
		Response response = APICall.GetAPIcall(URIConfigurations.GetPayCodeByID,URIConfigurations.GetPayCodeByID, headers);

		// validations
		APIResponse.verify_response(response, "data.options.value", "PERSONAL");
		APIResponse.verify_Response_StatusCode(response, APIResponseMessages.StatusCode_200);
		APIResponse.verify_Response_StatusLine(response, APIResponseMessages.StatusLine_HTTP_200);
		APIResponse.verify_Response_Header(response, APIResponseMessages.Header_content_type);
		APIResponse.verify_Response_Header(response, APIResponseMessages.Header_Connection);
	}


}
