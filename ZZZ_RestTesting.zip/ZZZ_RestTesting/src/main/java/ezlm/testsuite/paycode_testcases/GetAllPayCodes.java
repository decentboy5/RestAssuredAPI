package ezlm.testsuite.paycode_testcases;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import ezlm.APIAutomation.Utilities.APIResponseMessages;
import ezlm.APIAutomation.Utilities.APIBaseClass;
import ezlm.APIAutomation.Utilities.APICall;
import ezlm.APIAutomation.Utilities.APIResponse;
import ezlm.APIAutomation.Utilities.Headers;
import ezlm.APIAutomation.Utilities.URIConfigurations;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class GetAllPayCodes extends APIBaseClass {
	
	@Test(priority = 1)
	public void GetPayCodes_With_Valid_Values() throws IOException {

		// Get Headers from Property File
		headers = Headers.getHeaders("PayCode/GetHeaders.properties");

		// Get Call with URI and Headers
		Response response = APICall.GetAPIcall(URIConfigurations.GetAllPayCodesURI,URIConfigurations.GetAllPayCodes_Resource,headers);

		// validations
		APIResponse.verify_response(response, "data.options.value", "PERSONAL");
		APIResponse.verify_Response_StatusCode(response, APIResponseMessages.StatusCode_200);
		APIResponse.verify_Response_StatusLine(response, APIResponseMessages.StatusLine_HTTP_200);
		APIResponse.verify_Response_Header(response, APIResponseMessages.Header_content_type);
		APIResponse.verify_Response_Header(response, APIResponseMessages.Header_Connection);
	}

/*	@Test(priority = 2)
	public void GetPayCodes_Without_Culture() throws IOException {

		// Get Headers from Property File
		headers = Headers.getHeaders("PayCode/GetHeaders.properties");
		headers.replace("culture", "");

		// Get Call with URI and Headers
		Response response = APICall.GetAPIcall(URIConfigurations.GetAllPayCodesURI,URIConfigurations.GetAllPayCodes_Resource,headers);

		// validations
		APIResponse.verify_response(response, "data.statusDescription", "Need a valid value for culture");
		APIResponse.verify_Response_StatusCode(response, APIResponseMessages.StatusCode_401);
		APIResponse.verify_Response_StatusLine(response, APIResponseMessages.StatusLine_HTTP_401);
		APIResponse.verify_response(response, "data.status", APIResponseMessages.failure_status);
		APIResponse.verify_response(response, "data.statusCode", APIResponseMessages.StatusCode_404);
		APIResponse.verify_Response_Header(response, APIResponseMessages.Header_content_type);
		APIResponse.verify_Response_Header(response, APIResponseMessages.Header_Connection);
	}*/

}
