package ezlm.testsuite.paycode_testcases;

import java.io.IOException;
import java.util.HashMap;
import org.testng.annotations.Test;

import ezlm.APIAutomation.Utilities.APIResponseMessages;
import ezlm.APIAutomation.Utilities.APIBaseClass;
import ezlm.APIAutomation.Utilities.APICall;
import ezlm.APIAutomation.Utilities.APIResponse;
import ezlm.APIAutomation.Utilities.Headers;
import ezlm.APIAutomation.Utilities.URIConfigurations;
import io.restassured.response.Response;

public class AddPayCode extends APIBaseClass{
	
	@Test
	public void AppPayCode() throws IOException
	{
		/* Getting headers from Property File */
		headers=Headers.getHeaders("PayCode/POSTHeaders.properties");
	
		/* Hitting Rest POST call */
		Response response=APICall.POSTAPIcall(URIConfigurations.AddPayCodeURI, headers);	
		
		/* Validations */
		APIResponse.verify_response(response, "status", "success");
		APIResponse.verify_Response_Header(response,APIResponseMessages.Header_Connection);
		APIResponse.verify_Response_Header(response,APIResponseMessages.Header_content_type);
		APIResponse.verify_Response_StatusCode(response, APIResponseMessages.StatusCode_200);
		APIResponse.verify_Response_StatusLine(response,APIResponseMessages.StatusLine_HTTP_200);

		
	}
}
