package ezlm.APIAutomation.Utilities;

public class Candelete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Hello World";
		String a=s.join("-","helo","dsdasda");
				
				System.out.println(a);
	}

}
