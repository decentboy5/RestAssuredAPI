package ezlm.APIAutomation.Utilities;

import java.util.ArrayList;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class APIResponse {

	
	/***
	 * 
	 * @param response
	 *            : Response object for the API Request
	 * @param keyORXpath
	 *            : specfic key or XPATH to check in the response
	 * @param expectedvalue
	 *            The value to check in the response for the given key or XPATH
	 * 
	 */
	@SuppressWarnings("unchecked")
	public static void verify_response(Response response, String keyORXpath, String expectedvalue) {

		System.out.println(" ");
		Object responsevalue_Obj = null;
		String StringORArrayList = null;
		try {

			boolean status = false;
			System.out.println("");

			JsonPath jsonPathEvaluator = response.jsonPath();
			responsevalue_Obj = jsonPathEvaluator.get(keyORXpath);
			StringORArrayList = responsevalue_Obj.getClass().getSimpleName();
			if (StringORArrayList.toLowerCase().equals("arraylist")) {
				ArrayList<String> actualvalue_List = (ArrayList<String>) responsevalue_Obj;
				for (String _actualvalue : actualvalue_List) {

					if (_actualvalue.contains(expectedvalue)) {
						status = true;
						break;
					}
				}
				if (!status) {					
					Assert.fail(expectedvalue + "           is Not present in the response body");
				}
			} else {
				responsevalue_Obj = responsevalue_Obj.toString();
				Assert.assertEquals(responsevalue_Obj, expectedvalue);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/***
	 * 
	 * @param response
	 * @param expected_StatusCode
	 */
	public static void verify_Response_StatusCode(Response response, int expected_StatusCode) {

		try {
			int actual_Statuscode = response.getStatusCode();
			Assert.assertEquals(actual_Statuscode, expected_StatusCode);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_StatusLine(Response response, String expected_StatusLine) {

		try {
			String actual_StatusLine = response.getStatusLine();
			actual_StatusLine = actual_StatusLine.trim();
			Assert.assertEquals(actual_StatusLine, expected_StatusLine);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_Header(Response response, String Expected_header_name) {

		try {
			String header_Response = response.getHeader(Expected_header_name);
			if (Expected_header_name.equals("Content-Type")) {
				Assert.assertEquals(header_Response, "application/json");
			} else if (Expected_header_name.equals("Connection")) {
				Assert.assertEquals(header_Response, "Keep-Alive");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}
