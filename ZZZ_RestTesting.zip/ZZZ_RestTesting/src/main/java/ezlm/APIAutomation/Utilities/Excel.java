package ezlm.APIAutomation.Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

	/**
	 * Used to Read Complete data based on Sheet Name
	 * 
	 * @param excelFilePath
	 *            : Excel sheet path
	 * 
	 * @param sheetname
	 *            : SheetName
	 * 
	 * 
	 */
	public static LinkedHashMap<String, LinkedList<String>> GetExcelData(String excelFilePath, String sheetname)
			throws IOException {

		try {

			LinkedList<String> Header_data = new LinkedList<String>();
			LinkedHashMap<String, LinkedList<String>> testdata = new LinkedHashMap<String, LinkedList<String>>();

			FileInputStream inputStream = new FileInputStream(excelFilePath);

			@SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheet(sheetname);
			XSSFCell cell;

			// For storing the headers
			XSSFRow Header = sheet.getRow(0);

			int _totalheaders = Header.getPhysicalNumberOfCells();

			for (int i = 0; i < _totalheaders; i++) {
				cell = Header.getCell(i);
				if (cell != null)
					Header_data.add(cell.getStringCellValue());
			}

			int Testdata_rows = sheet.getLastRowNum() - sheet.getFirstRowNum();
			int _cell = 0;

			for (String header : Header_data) {

				LinkedList<String> data = new LinkedList<String>();

				for (int i = 1; i <= Testdata_rows; i++) {
					XSSFRow Row = sheet.getRow(i);

					if (Row != null) {
						cell = Row.getCell(_cell);
						if (cell != null) {
							if (cell.getCellType() == cell.CELL_TYPE_STRING) {
								data.add(sheet.getRow(i).getCell(_cell).getStringCellValue());
							} else if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
								data.add(String.valueOf(sheet.getRow(i).getCell(_cell).getNumericCellValue()));
							}
						}
					}
				}

				_cell++;
				testdata.put(header, data);
			}

			return testdata;
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	/**
	 * Used to Read the Specific row data from Excel based on given Row Number
	 * 
	 * @param excelFilePath
	 *            : Excel sheet path
	 * 
	 * @param sheetname
	 *            : SheetName
	 * 
	 * @param rownumber
	 *            : Row number in the Excel sheet
	 */
	public static LinkedHashMap<String, String> GetExcelData(String excelFilePath, String sheetname, int rownumber)
			throws IOException {

		try {

			LinkedList<String> Header_data = new LinkedList<String>();
			LinkedHashMap<String, String> testdata = new LinkedHashMap<String, String>();

			FileInputStream inputStream = new FileInputStream(excelFilePath);

			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheet(sheetname);
			XSSFCell cell;
			// For storing the headers
			XSSFRow Header = sheet.getRow(0);

			int totalheaders = Header.getPhysicalNumberOfCells();

			for (int i = 0; i < totalheaders; i++) {
				cell = Header.getCell(i);
				if (cell != null)
					Header_data.add(cell.getStringCellValue());
			}

			int Testdata_rows = sheet.getLastRowNum() - sheet.getFirstRowNum();
			int _cell = 0;

			for (String header : Header_data) {

				String data = null;
				// LinkedList<String> data = new LinkedList<String>();

				XSSFRow Row = sheet.getRow(rownumber - 1);

				if (Row != null) {
					cell = Row.getCell(_cell);
					if (cell != null) {
						if (cell.getCellType() == cell.CELL_TYPE_STRING) {
							data = sheet.getRow(rownumber - 1).getCell(_cell).getStringCellValue();
							// data.add(sheet.getRow(rownumber -
							// 1).getCell(_cell).getStringCellValue());
						} else if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
							// data.add(String.valueOf(sheet.getRow(rownumber -
							// 1).getCell(_cell).getNumericCellValue()));
							data = String.valueOf(sheet.getRow(rownumber - 1).getCell(_cell).getNumericCellValue());
						}
					}

				}

				_cell++;
				testdata.put(header, data);
			}

			return testdata;
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	/**
	 * Used to Read the Specific Cell data from Excel based on Row Number and
	 * Column Name
	 * 
	 * * @param excelFilePath : Excel sheet path
	 * 
	 * @param sheetname
	 *            : SheetName
	 * 
	 * @param rownumber
	 *            : Row number in the Excel sheet
	 * 
	 * @param ColumnName
	 *            : Column Header in the Excel Sheet
	 */
	public static String GetExcelData(String excelFilePath, String sheetname, String ColumnName, int rownumber)
			throws IOException {
		String testdata = null;

		ColumnName = ColumnName.toUpperCase();


		try {
			System.out.println("       ");
			LinkedList<String> headers_excel = new LinkedList<String>();
			LinkedHashMap<String, LinkedList<String>> testdata_t = new LinkedHashMap<String, LinkedList<String>>();

			FileInputStream inputStream = new FileInputStream(excelFilePath);

			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheet(sheetname);

			// For storing the headers
			XSSFRow Header = sheet.getRow(0);

			int totalheaders = Header.getPhysicalNumberOfCells();

			for (int i = 0; i < totalheaders; i++) {
				// if(Header.getCell(i).getStringCellValue()="")
				headers_excel.add(Header.getCell(i).getStringCellValue().toUpperCase());
			}

			int Testdata_rows = sheet.getLastRowNum() - sheet.getFirstRowNum();
			int cell = 0;

			LinkedList<String> data = new LinkedList<String>();
			for (String header : headers_excel) {

				if (header.toUpperCase().equals(ColumnName.toUpperCase())) {

					XSSFRow Row = sheet.getRow(rownumber - 1);
					if (Row != null) {
						XSSFCell _cell = Row.getCell(cell);
						if (_cell != null) {
							if (_cell.getCellType() == _cell.CELL_TYPE_STRING) {
								testdata = sheet.getRow(rownumber - 1).getCell(cell).getStringCellValue();

							} else if (_cell.getCellType() == _cell.CELL_TYPE_NUMERIC) {
								testdata = String
										.valueOf(sheet.getRow(rownumber - 1).getCell(cell).getNumericCellValue());

							}
						}

					}

				}
				cell++;

			}

		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
		return testdata;
	}

	/**
	 * This is for Reading the Row data based on First Row condition
	 * 
	 * @param excelFilePath
	 * @param sheetname
	 * @param PODNAME
	 * @return
	 * @throws IOException
	 */
	public static LinkedHashMap<String, String> GetExcelData(String excelFilePath, String sheetname, String PODNAME)
			throws IOException {

		try {
			int rownumber = 0;
			LinkedList<String> Header_data = new LinkedList<String>();
			LinkedHashMap<String, String> testdata = new LinkedHashMap<String, String>();

			FileInputStream inputStream = new FileInputStream(excelFilePath);

			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheet(sheetname);
			XSSFCell cell;
			// For storing the headers
			XSSFRow Header = sheet.getRow(0);

			int totalheaders = Header.getPhysicalNumberOfCells();

			for (int i = 0; i < totalheaders; i++) {
				cell = Header.getCell(i);
				if (cell != null)
					Header_data.add(cell.getStringCellValue());
			}

			int Testdata_rows = sheet.getLastRowNum() - sheet.getFirstRowNum();
			int _cell = 0;

			// Identify the row number for the Specified POD NAME
			if (Header_data.get(0).contains("PODNAME")) {
				for (int i = 0; i <= Testdata_rows; i++) {
					String _podname = sheet.getRow(i).getCell(_cell).toString();
					if (_podname.equalsIgnoreCase(PODNAME)) {
						rownumber = i + 1;
						break;
					}

				}
			}

			for (String header : Header_data) {

				String data = null;
				// LinkedList<String> data = new LinkedList<String>();

				XSSFRow Row = sheet.getRow(rownumber - 1);

				if (Row != null) {
					cell = Row.getCell(_cell);
					if (cell != null) {
						if (cell.getCellType() == cell.CELL_TYPE_STRING) {
							data = sheet.getRow(rownumber - 1).getCell(_cell).getStringCellValue();
							// data.add(sheet.getRow(rownumber -
							// 1).getCell(_cell).getStringCellValue());
						} else if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
							// data.add(String.valueOf(sheet.getRow(rownumber -
							// 1).getCell(_cell).getNumericCellValue()));
							data = String.valueOf(sheet.getRow(rownumber - 1).getCell(_cell).getNumericCellValue());
						}
					}

				}

				_cell++;
				testdata.put(header, data);
			}

			return testdata;
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	public static LinkedHashMap<String, String> GetExcelData(String excelFilePath, String sheetname, float abc)
			throws IOException {

		try {

			LinkedList<String> Header_data = new LinkedList<String>();
			LinkedHashMap<String, String> testdata = new LinkedHashMap<String, String>();

			FileInputStream inputStream = new FileInputStream(excelFilePath);

			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheet(sheetname);
			XSSFCell cell;
			// For storing the headers
			XSSFRow Header = sheet.getRow(0);

			int totalheaders = Header.getPhysicalNumberOfCells();

			for (int i = 0; i < totalheaders; i++) {
				cell = Header.getCell(i);
				if (cell != null)
					Header_data.add(cell.getStringCellValue());
			}

			int Testdata_rows = sheet.getLastRowNum() - sheet.getFirstRowNum();
			int _cell = 0;

			for (String header : Header_data) {

				String data = null;
				// LinkedList<String> data = new LinkedList<String>();

				XSSFRow Row = sheet.getRow(1);

				if (Row != null) {
					cell = Row.getCell(_cell);
					if (cell != null) {
						if (cell.getCellType() == cell.CELL_TYPE_STRING) {
							data = sheet.getRow(1).getCell(_cell).getStringCellValue();
							// data.add(sheet.getRow(rownumber -
							// 1).getCell(_cell).getStringCellValue());
						} else if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
							// data.add(String.valueOf(sheet.getRow(1).getCell(_cell).getNumericCellValue()));
							data = String.valueOf(sheet.getRow(1).getCell(_cell).getNumericCellValue());
						}
					}

				}

				_cell++;
				testdata.put(header, data);
			}

			return testdata;
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
}
