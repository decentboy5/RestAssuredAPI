package ezlm.APIAutomation.Utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.testng.Assert;

import ezlm.api.reusableMethods.PayCode;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APICall {

	public static Logger log = Logger.getLogger(APICall.class);

	public static String Get_ResponseBody(String uri, HashMap<String, String> headers) {
		String responseBody = null;
		try {

			RestAssured.baseURI = uri;
			RequestSpecification httpRequest = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				httpRequest.header(data.getKey(), data.getValue());
			}

			Response response = httpRequest.request(Method.GET, "/paycode");

			// Now let us print the body of the message to see what response
			// we have recieved from the server
			responseBody = response.getBody().asString();
			return responseBody;

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return responseBody;
	}

	/**
	 * This is for Get API Call
	 * 
	 * @param uri
	 * @param resource
	 * @param headers
	 * @return
	 */
	public static Response GetAPIcall(String uri, String resource, HashMap<String, String> headers) {
		Response response = null;

		try {

			log.info("Given URI    :    " + uri);
			log.info("Headers      :   " + headers);
			RestAssured.baseURI = uri;
			//RestAssured.basePath="PayCode_API88494";
		
			

			RequestSpecification httpRequest = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				String HeaderKey = data.getKey();
				String HeaderValue = data.getValue();
				if (HeaderKey == null)
					HeaderKey = "";
				if (HeaderValue == null)
					HeaderValue = "";
				httpRequest.header(HeaderKey, HeaderValue);
			}
		//	httpRequest.get("PayCode_API88494");
			
			response = httpRequest.request(Method.GET,resource);
			log.info("API Response    :   \n" + response.getBody().asString());
			return response;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return response;
	}

	public static Response POSTAPIcall(String uri, HashMap<String, String> headers) {
		Response response = null;

		try {

			RestAssured.baseURI = uri;
			RequestSpecification request = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				request.header(data.getKey(), data.getValue());
			}
			request.body(PayCode.AddPayCodeBody("nonworked", "payCodeRate"));
			response = request.post("/paycode.add");
			System.out.println("Response body: " + response.body().asString());
			return response;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return response;
	}

	/***
	 * 
	 * @param response
	 *            : Response object for the API Request
	 * @param keyORXpath
	 *            : specfic key or XPATH to check in the response
	 * @param expectedvalue
	 *            The value to check in the response for the given key or XPATH
	 * 
	 */
	@SuppressWarnings("unchecked")
	public static void verify_response(Response response, String keyORXpath, String expectedvalue) {

		System.out.println(" ");
		Object responsevalue_Obj = null;
		String StringORArrayList = null;
		try {

			boolean status = false;
			System.out.println("");

			JsonPath jsonPathEvaluator = response.jsonPath();
			responsevalue_Obj = jsonPathEvaluator.get(keyORXpath);
			StringORArrayList = responsevalue_Obj.getClass().getSimpleName();
			if (StringORArrayList.toLowerCase().equals("arraylist")) {
				ArrayList<String> actualvalue_List = (ArrayList<String>) responsevalue_Obj;
				for (String _actualvalue : actualvalue_List) {

					if (_actualvalue.contains(expectedvalue)) {
						status = true;
						break;
					}
				}
				if (!status) {
					Assert.fail(expectedvalue + "           is Not present in the response body");
				}
			} else {
				responsevalue_Obj = responsevalue_Obj.toString();
				Assert.assertEquals(responsevalue_Obj, expectedvalue);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/***
	 * 
	 * @param response
	 * @param expected_StatusCode
	 */
	public static void verify_Response_StatusCode(Response response, int expected_StatusCode) {

		try {
			int actual_Statuscode = response.getStatusCode();
			Assert.assertEquals(actual_Statuscode, expected_StatusCode);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_StatusLine(Response response, String expected_StatusLine) {

		try {
			String actual_StatusLine = response.getStatusLine();
			actual_StatusLine = actual_StatusLine.trim();
			Assert.assertEquals(actual_StatusLine, expected_StatusLine);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_Header(Response response, String Expected_header_name) {

		try {
			String header_Response = response.getHeader(Expected_header_name);
			if (Expected_header_name.equals("Content-Type")) {
				Assert.assertEquals(header_Response, "application/json");
			} else if (Expected_header_name.equals("Connection")) {
				Assert.assertEquals(header_Response, "Keep-Alive");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
