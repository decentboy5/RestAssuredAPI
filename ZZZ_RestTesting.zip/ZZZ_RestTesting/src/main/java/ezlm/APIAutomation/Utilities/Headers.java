package ezlm.APIAutomation.Utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

public class Headers {

	
	
	public static HashMap<String, String> getHeaders(String path) throws IOException
	{
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"/API/Headers/"+path);
		HashMap<String,String> headers=new HashMap<String, String>();
       Properties prop=new Properties();
       prop.load(file);
       Set<Object> keys=prop.keySet();
       
       	for (Object object : keys) {
			
       		headers.put((String) object, prop.getProperty((String) object));
		}
       	return headers;
       
	}
}
