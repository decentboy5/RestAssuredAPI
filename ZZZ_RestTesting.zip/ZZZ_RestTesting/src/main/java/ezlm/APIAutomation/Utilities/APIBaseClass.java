package ezlm.APIAutomation.Utilities;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

public class APIBaseClass {

	public static HashMap<String, String> headers = null;
	public static Logger log=Logger.getLogger(APIBaseClass.class);
	
	public APIBaseClass() {
		// TODO Auto-generated constructor stub
	}
	
	@BeforeSuite
	public void beforesuite(ITestContext context)
	{
		System.out.println("suite name"+context.getSuite().getName());
		Map<String, String> abc=context.getCurrentXmlTest().getSuite().getParameters();
		System.out.println(" values are "+abc.get("dsadsada"));
	}
	
	@BeforeMethod
	public void beforeMethod(Method method) throws IOException {

		log.info("-------------" + method.getName() + "   Started------------------------------------------------");
		log.info("                                                                                                ");

	}

	@AfterMethod
	public void afterMethod(Method method) throws IOException {

		log.info("                                                                                              ");
		log.info("--------------" + method.getName() + "   Ended------------------------------------------------");
		log.info("                                                                                              ");


	}
}
