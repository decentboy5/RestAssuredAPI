package ezlm.APIAutomation.Utilities;

public class URIConfigurations {

	public static String GetAllPayCodesURI="http://mascsr.dit.oneadp.com/mascsr/wfntlm/codelists/v1";
	
	public static String AddPayCodeURI="http://mascsr.dit.oneadp.com/mascsr/wfntlm/config/v1";
	
	public static String GetAllPayCodes_Resource="/payCode";
	
	public static String GetPayCodeByID_Resource="/PayCode_API02435";
	
	public static String GetPayCodeByID="http://mascsr.dit.oneadp.com/mascsr/wfntlm/config/v1/paycode";


	
}
