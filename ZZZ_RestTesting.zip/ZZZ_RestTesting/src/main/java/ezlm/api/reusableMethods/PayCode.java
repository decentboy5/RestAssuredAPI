package ezlm.api.reusableMethods;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.simple.JSONObject;

public class PayCode {

	
	
	/**
	 * 
	 * @param workedType
	 * @param rateCalcType
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String AddPayCodeBody(String workedtype,String rateCalcType)
	{
		DateFormat dateformat=new SimpleDateFormat("yyyy-mm-dd");
		Date d=new Date();dateformat.format(d);
		Object payCodeId="Paycode_API"+RandomStringUtils.random(5,false,true);
		JSONObject requestParams = new JSONObject();
		requestParams.put("payCodeId", payCodeId); // Cast
		requestParams.put("payType", "normal");
		requestParams.put("workedType", "worked");
		requestParams.put("alreadyPaidPayCode", null);	
		requestParams.put("transferToPayroll",  "true");
		requestParams.put("jobHierarchy", "none");
		requestParams.put("rateCalcType", "payCodeRate");
		requestParams.put("payrollXferCodes", "73562.12");
		requestParams.put("canEnterOnTimeCard", "true");
		requestParams.put("distributeTime", "false");
		requestParams.put("defaultAmount", "100");
		requestParams.put("guaranteedHrs", "100");
		requestParams.put("entryType", "hours");
		requestParams.put("sendToClocks", "false");
		requestParams.put("guaranteedShiftDiff","false");
		requestParams.put("useWageRateProgram", "false");
		requestParams.put("includeInZooms", "true");
		requestParams.put("excludeHrsFromViews","false");
		requestParams.put("useAvgProHours", "false");
		requestParams.put("useAvgProWage", "false");
		requestParams.put("useScheduledHolidayHours", "false");
		requestParams.put("countForProbation", "true");
		requestParams.put("countForWorkTime", "true");
		requestParams.put("countForAvgDay", "false");
		requestParams.put("suppresSOTs", "false");	
		requestParams.put("activateAlternateThreshold", "false");	
		requestParams.put("countForShiftDiff", "true");	
		requestParams.put("excludeFromTimeGen", "false");	
		requestParams.put("countAsPaid", "true");	
		requestParams.put("timeCardColumn", 1);
		List<Object> s=new LinkedList<Object>();
		JSONObject s1 = new JSONObject();
		s1.put("payGroupId", "SALARY");
		s1.put("includeInZooms", "true");
		s.add(s1);
		requestParams.put("payGroupList",s);
		JSONObject s2 = new JSONObject();
		s2.put("effectiveDate", (Object)dateformat.format(d));
		s2.put("rateAmount", 7);
		s=new LinkedList<Object>();
		s.add(s2);
		requestParams.put("payCodeRates",s);
		requestParams.put("payShiftDiff", "true");
		JSONObject s3 = new JSONObject();
		s3.put("culture", "en-US");
		s3.put("description", "Regular");
		s=new LinkedList<Object>();
		s.add(s3);
		requestParams.put("descriptions",s);
		System.out.println(requestParams.toJSONString());
		return requestParams.toJSONString();
		
	}
}
